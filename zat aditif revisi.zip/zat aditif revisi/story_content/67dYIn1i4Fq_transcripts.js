
(function() {
    const data = {"transcripts":[{"name":"captions","cues":[{"start":39,"text":"Tahukah kamu berapa banyak gula dan zat aditif"},{"start":2799,"text":"yang tanpa sadar kita makan setiap hari?"},{"start":4920,"text":"Yuk,"},{"start":5239,"text":"kita bongkar misterinya lewat pembelajaran seru hari ini."},{"start":8520,"text":"Yuk tekan tombol mulai."}]}]};
    window.globalLoadJsAsset('story_content/67dYIn1i4Fq_transcripts.js', JSON.stringify(data));
})();